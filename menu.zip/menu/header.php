<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">   
        <title>Restaurant Name</title>
        <meta name="description" content="">
        <meta name="author" content="">

        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

        <!-- Stylesheets -->
        <link rel="stylesheet" href="css/bootstrap.css" />
        <link rel="stylesheet" href="css/bootstrap-responsive.css" />
        <link rel="stylesheet" href="style.css" />
    </head>

    

