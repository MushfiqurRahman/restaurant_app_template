<?php include 'header.php'; ?>
	<div class=" item" style="margin-right:10px;">
		<h2 style=" line-height: 15px; padding: 10px 0 10px 10px; border-bottom: 1px dotted #cccccc;" > Name </h2>
	
		<div class=" span2" style="height:30px;line-height: 15px; margin:2px;">
			<small style="line-height: 10px;"> description of product</small>
		</div>

			<div class="pull-left ">
				<img src="item.png" a alt="..." class="img-item" style="height:200px; width:300px;  margin: 60px 0 10px 10px;  float:left;">

             </div>

         <div class="" style="margin-top:249px; ">
            <h3 style=" margin-left:320px;"> Price: </h3>
             	<img src="order.png" a alt="..." class="" style="float:right; margin-top: -85px;">
         </div>
       

	</div>


