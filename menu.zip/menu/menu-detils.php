<?php include 'header.php'; ?>
	<div class=" menu" style="margin-right:10px;">
			<div class="pull-left " style="">
				<img src="item.png" a alt="..." class="img-item" style="height:250px; width:300px;  margin: 15px 0 10px 10px;  float:left;">

			 </div>


			 <div class="pull-left" style="margin:10px 0px 0px 20px;   width:74%;"  >
					<h2 style=" margin: 10px 0 5px 10px; padding: 10px 0 10px 10px; " > Name </h2>
	
					<div class=" span2" style="height:30px;line-height: 15px; margin:2px;">
						<small style="line-height: 10px;"> description of product</small>
					</div>
					<img src="order.png" a alt="..." class="" style="float:right; height:115px; width:100;">

					<hr style="margin-top:130px">

					 <div class="" style="">
           				 <h3 style=" margin-left:320px;"> Price: </h3>
             	
         			</div>


			 </div>
			

	</div>


