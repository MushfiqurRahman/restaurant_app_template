<?php include 'header.php'; ?>

<ul style="list-style-type: none;">
	<li><button type="button"  class="btn-text  btnsidebar"style="background-image:url('buton2.png');

text-align:left; border-top: 0px;
  border-bottom: 0px;
  border-right: 0px;
    color: #FFFFFF; margin:0; height:55px; width:1310px;">Appetizer</button></li>
<li><button type="button" style="background-image:url('buton2.png');

text-align:left; border-top: 0px;
  border-bottom: 1px solid #a6a6a6;
  border-right: 0px;
    color: #FFFFFF; margin:0; height:55px; width:1310px;">Appetizer</button> </li>
</ul> 

